(function () {
  var mapInstance = null;
  var marker = null;
  var circles = [];

  function clearMap() {
    circles.forEach(function (c) { c.setMap(null); });
    circles = [];
    if (marker) { marker.setMap(null); marker = null; }
    mapInstance = null;
  }

  function loadMaps(apiKey) {
    if (window.google && window.google.maps) return Promise.resolve();
    return new Promise(function (resolve, reject) {
      var id = "ok-gmaps-script";
      var existing = document.getElementById(id);
      if (existing) {
        if (window.google && window.google.maps) { resolve(); return; }
        existing.addEventListener("load", resolve);
        existing.addEventListener("error", reject);
        return;
      }
      window.okMapsReady = function () { delete window.okMapsReady; resolve(); };
      var s = document.createElement("script");
      s.id = id;
      s.async = true;
      s.src = "https://maps.googleapis.com/maps/api/js?key="
        + encodeURIComponent(apiKey) + "&callback=okMapsReady";
      s.onerror = function () { reject(new Error("maps")); };
      document.head.appendChild(s);
    });
  }

  function initAdminZoneMap() {
    var el = document.getElementById("adminZoneMap");
    var dataEl = document.getElementById("adminZoneMapData");
    if (!el || !dataEl) return;
    var key = el.getAttribute("data-maps-key");
    if (!key) return;

    var data;
    try { data = JSON.parse(dataEl.textContent); } catch (e) { return; }
    if (data.lat == null || data.lng == null) return;

    loadMaps(key).then(function () {
      clearMap();
      var center = { lat: Number(data.lat), lng: Number(data.lng) };
      mapInstance = new google.maps.Map(el, {
        center: center,
        zoom: 12,
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: true,
      });
      marker = new google.maps.Marker({
        position: center,
        map: mapInstance,
        title: data.name || "",
      });
      var bounds = new google.maps.LatLngBounds();
      bounds.extend(center);
      (data.zones || []).forEach(function (z) {
        var miles = parseFloat(z.radius_miles) || 0;
        if (miles <= 0) return;
        var circle = new google.maps.Circle({
          map: mapInstance,
          center: center,
          radius: miles * 1609.344,
          strokeColor: z.color || "#E0A200",
          strokeOpacity: 0.9,
          strokeWeight: 2,
          fillColor: z.color || "#E0A200",
          fillOpacity: 0.14,
        });
        circles.push(circle);
        bounds.union(circle.getBounds());
      });
      if ((data.zones || []).length) mapInstance.fitBounds(bounds, 56);
    }).catch(function () {});
  }

  window.initAdminZoneMap = initAdminZoneMap;
})();
