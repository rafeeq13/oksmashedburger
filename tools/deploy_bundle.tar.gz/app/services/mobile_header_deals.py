"""Blinking deals image between logo and search on mobile header only."""
import json
from app.extensions import db
from app.models.site import SiteSetting

SETTING_KEY = "mobile_header_deals"
# Matches logo height in header (.ok-h-11) inside the 4rem mobile bar (.ok-h-16).
MOBILE_CHIP_HEIGHT_PX = 44
MOBILE_HEADER_BAR_PX = 64

DEFAULT = {
    "enabled": False,
    "image": "",
    "width_px": 72,
    "link": "/deals",
}


def normalize(raw):
    base = dict(DEFAULT)
    if isinstance(raw, dict):
        base.update(raw)
    link = (base.get("link") or "/deals").strip() or "/deals"
    if not link.startswith("/") and not link.startswith("http"):
        link = "/" + link.lstrip("/")
    image = (base.get("image") or "").strip()[:2000]
    try:
        width = int(base.get("width_px", DEFAULT["width_px"]))
    except (TypeError, ValueError):
        width = DEFAULT["width_px"]
    width = max(32, min(160, width))
    return {
        "enabled": bool(base.get("enabled")),
        "image": image,
        "width_px": width,
        "link": link[:500],
        "display_height_px": MOBILE_CHIP_HEIGHT_PX,
        "header_bar_px": MOBILE_HEADER_BAR_PX,
    }


def load_mobile_header_deals():
    row = SiteSetting.query.filter_by(key=SETTING_KEY).first()
    if not row or not row.value:
        return normalize({})
    try:
        data = json.loads(row.value)
    except Exception:
        return normalize({})
    return normalize(data if isinstance(data, dict) else {})


def save_mobile_header_deals(cfg):
    normalized = normalize(cfg)
    payload = json.dumps(normalized, separators=(",", ":"))
    row = SiteSetting.query.filter_by(key=SETTING_KEY).first()
    if row:
        row.value = payload
    else:
        db.session.add(SiteSetting(key=SETTING_KEY, value=payload))
    db.session.commit()
    return normalized


def visible(cfg):
    if not cfg or not cfg.get("enabled"):
        return False
    return bool((cfg.get("image") or "").strip())
