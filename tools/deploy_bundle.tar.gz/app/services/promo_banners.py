"""Per-location promotional image banners (admin-configured)."""
import json
import re

from app.extensions import db
from app.models.site import SiteSetting

GLOBAL_SETTING_KEY = "promo_banner"
SETTING_KEY = GLOBAL_SETTING_KEY  # backwards compat
# On-page editor (?edit=1) tags banner pictures with this slot key.
INLINE_IMAGE_KEY = "promo_banner_image"

PROMO_IMAGE_SPEC = {"build_size": "2800×440"}

DEFAULT_PROMO_BANNER = {
    "enabled": True,
    "placement": "visit_popup",
    "height": 88,
    "width": "container",
    "use_image": True,
    "image": (
        "https://images.unsplash.com/photo-1550547660-d9450f859349"
        "?w=1400&h=280&fit=crop&q=80"
    ),
    "image_position": "center center",
    "bg_color": "#f5c518",
    "link": "/deals",
    "text": "Exclusive deals — tap to save",
    "text_color": "#ffffff",
    "text_size": 15,
    "text_font": "",
    "show_text": True,
    "overlay": 0.45,
    "border_style": "blink",
    "show_subscribe": False,
    "subscribe_label": "Get deals",
    "subscribe_border_color": "#ffffff",
    "subscribe_input_color": "#ffffff",
    "subscribe_bar_bg_color": "#0c0c0c",
    "subscribe_bar_transparent": False,
    "deals_link_color": "#f5c518",
    "subscribe_placeholder_color": "#ffffff",
    "subscribe_btn_text_color": "#141414",
    "subscribe_btn_bg_color": "#f5c518",
    "deals_link_size": 15,
    "subscribe_input_size": 16,
    "subscribe_btn_size": 13,
    "deals_btn_text_color": "#111111",
    "mobile_text_size": 11,
    "mobile_deals_link_size": 11,
    "mobile_subscribe_input_size": 13,
    "mobile_subscribe_btn_size": 11,
    "popup_close_size": 36,
    "popup_close_bg_color": "#ffffff",
    "popup_close_color": "#111111",
}

_PLACEMENTS = frozenset({"visit_popup", "above_header", "below_header", "above_footer"})
_WIDTHS = frozenset({"full", "container"})
_BORDER_STYLES = frozenset({"none", "static", "blink"})


def setting_key_for_store(store):
    """SiteSetting key for one location's banner override (or brand default)."""
    if store and getattr(store, "slug", None):
        return f"promo_banner__{store.slug}"
    return GLOBAL_SETTING_KEY


def _clamp_int(val, default, lo, hi):
    try:
        n = int(val)
    except (TypeError, ValueError):
        return default
    return max(lo, min(hi, n))


def _clamp_float(val, default, lo, hi):
    try:
        n = float(val)
    except (TypeError, ValueError):
        return default
    return max(lo, min(hi, n))


def _hex_color(raw, default):
    val = (raw or default or "").strip()
    if not re.match(r"^#[0-9A-Fa-f]{3,8}$", val):
        return default
    return val


def normalize_promo_banner(raw):
    """Merge saved dict with defaults and coerce types."""
    base = dict(DEFAULT_PROMO_BANNER)
    if isinstance(raw, dict):
        base.update(raw)
    placement = (base.get("placement") or "visit_popup").strip()
    if placement == "above_header":
        placement = "visit_popup"
    if placement not in _PLACEMENTS:
        placement = "visit_popup"
    width = (base.get("width") or "container").strip()
    if width not in _WIDTHS:
        width = "container"
    use_image = bool(base.get("use_image", True))
    image = (base.get("image") or "").strip()
    if use_image and not image:
        image = DEFAULT_PROMO_BANNER["image"]
    bg_color = (base.get("bg_color") or DEFAULT_PROMO_BANNER["bg_color"]).strip()
    if not re.match(r"^#[0-9A-Fa-f]{3,8}$", bg_color):
        bg_color = DEFAULT_PROMO_BANNER["bg_color"]
    border_style = (base.get("border_style") or "").strip().lower()
    if border_style not in _BORDER_STYLES:
        border_style = "blink" if base.get("blink_border", True) else "none"
    link = (base.get("link") or "/deals").strip() or "/deals"
    if link.startswith("/") or link.startswith("http://") or link.startswith("https://"):
        pass
    else:
        link = "/" + link.lstrip("/")
    text = (base.get("text") or "").strip() or DEFAULT_PROMO_BANNER["text"]
    text_color = _hex_color(base.get("text_color"), DEFAULT_PROMO_BANNER["text_color"])
    img_pos = (base.get("image_position") or "center center").strip()[:80]
    text_font = (base.get("text_font") or "").strip()[:400]
    subscribe_label = (base.get("subscribe_label") or DEFAULT_PROMO_BANNER["subscribe_label"]).strip()
    subscribe_label = subscribe_label[:40] or DEFAULT_PROMO_BANNER["subscribe_label"]
    subscribe_border_color = _hex_color(
        base.get("subscribe_border_color"), DEFAULT_PROMO_BANNER["subscribe_border_color"]
    )
    subscribe_input_color = _hex_color(
        base.get("subscribe_input_color"), DEFAULT_PROMO_BANNER["subscribe_input_color"]
    )
    subscribe_bar_bg_color = _hex_color(
        base.get("subscribe_bar_bg_color"), DEFAULT_PROMO_BANNER["subscribe_bar_bg_color"]
    )
    deals_link_color = _hex_color(base.get("deals_link_color"), DEFAULT_PROMO_BANNER["deals_link_color"])
    deals_btn_text_color = _hex_color(
        base.get("deals_btn_text_color"), DEFAULT_PROMO_BANNER["deals_btn_text_color"]
    )
    subscribe_placeholder_color = _hex_color(
        base.get("subscribe_placeholder_color"), DEFAULT_PROMO_BANNER["subscribe_placeholder_color"]
    )
    subscribe_btn_text_color = _hex_color(
        base.get("subscribe_btn_text_color"), DEFAULT_PROMO_BANNER["subscribe_btn_text_color"]
    )
    subscribe_btn_bg_color = _hex_color(
        base.get("subscribe_btn_bg_color"), DEFAULT_PROMO_BANNER["subscribe_btn_bg_color"]
    )
    popup_close_bg_color = _hex_color(
        base.get("popup_close_bg_color"), DEFAULT_PROMO_BANNER["popup_close_bg_color"]
    )
    popup_close_color = _hex_color(
        base.get("popup_close_color"), DEFAULT_PROMO_BANNER["popup_close_color"]
    )
    return {
        "enabled": bool(base.get("enabled", True)),
        "placement": placement,
        "height": _clamp_int(base.get("height"), DEFAULT_PROMO_BANNER["height"], 16, 220),
        "width": width,
        "use_image": use_image,
        "image": image[:2000] if use_image else "",
        "image_position": img_pos,
        "bg_color": bg_color,
        "link": link[:500],
        "text": text[:240],
        "text_color": text_color,
        "text_size": _clamp_int(base.get("text_size"), 15, 10, 48),
        "text_font": text_font,
        "show_text": bool(base.get("show_text", True)),
        "overlay": _clamp_float(base.get("overlay"), 0.45, 0.0, 0.85),
        "border_style": border_style,
        "blink_border": border_style == "blink",
        "show_subscribe": bool(base.get("show_subscribe", False)),
        "subscribe_label": subscribe_label,
        "subscribe_border_color": subscribe_border_color,
        "subscribe_input_color": subscribe_input_color,
        "subscribe_bar_bg_color": subscribe_bar_bg_color,
        "subscribe_bar_transparent": bool(base.get("subscribe_bar_transparent", False)),
        "deals_link_color": deals_link_color,
        "deals_btn_text_color": deals_btn_text_color,
        "deals_link_size": _clamp_int(base.get("deals_link_size"), 15, 8, 32),
        "subscribe_input_size": _clamp_int(base.get("subscribe_input_size"), 16, 8, 32),
        "subscribe_btn_size": _clamp_int(base.get("subscribe_btn_size"), 13, 8, 32),
        "subscribe_placeholder_color": subscribe_placeholder_color,
        "subscribe_btn_text_color": subscribe_btn_text_color,
        "subscribe_btn_bg_color": subscribe_btn_bg_color,
        "mobile_text_size": _clamp_int(base.get("mobile_text_size"), 11, 8, 28),
        "mobile_deals_link_size": _clamp_int(base.get("mobile_deals_link_size"), 11, 8, 28),
        "mobile_subscribe_input_size": _clamp_int(base.get("mobile_subscribe_input_size"), 13, 8, 28),
        "mobile_subscribe_btn_size": _clamp_int(base.get("mobile_subscribe_btn_size"), 11, 8, 28),
        "popup_close_size": _clamp_int(base.get("popup_close_size"), 36, 24, 56),
        "popup_close_bg_color": popup_close_bg_color,
        "popup_close_color": popup_close_color,
    }


def _read_setting_raw(key):
    row = SiteSetting.query.filter_by(key=key).first()
    if not row or not row.value:
        return {}
    try:
        data = json.loads(row.value)
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _write_setting(key, normalized):
    payload = json.dumps(normalized, separators=(",", ":"))
    row = SiteSetting.query.filter_by(key=key).first()
    if row:
        row.value = payload
    else:
        db.session.add(SiteSetting(key=key, value=payload))
    db.session.commit()
    return normalized


def store_has_banner_override(store):
    if not store or not getattr(store, "slug", None):
        return False
    row = SiteSetting.query.filter_by(key=setting_key_for_store(store)).first()
    return bool(row and row.value)


def load_promo_banner(store=None):
    """Effective banner for a storefront location (store override + brand default)."""
    global_raw = _read_setting_raw(GLOBAL_SETTING_KEY)
    merged = dict(global_raw)
    if store and getattr(store, "slug", None):
        store_raw = _read_setting_raw(setting_key_for_store(store))
        if store_raw:
            merged.update(store_raw)
    return normalize_promo_banner(merged)


def load_promo_banner_global():
    """Brand-default banner only (admin screen without a location)."""
    return normalize_promo_banner(_read_setting_raw(GLOBAL_SETTING_KEY))


def save_promo_banner(cfg, store=None):
    """Save brand default (store=None) or a location's full override."""
    normalized = normalize_promo_banner(cfg)
    key = setting_key_for_store(store)
    return _write_setting(key, normalized)


def clear_store_promo_banner(store):
    if not store or not getattr(store, "slug", None):
        return False
    row = SiteSetting.query.filter_by(key=setting_key_for_store(store)).first()
    if not row:
        return False
    db.session.delete(row)
    db.session.commit()
    return True


def promo_banner_visible(cfg, features, path, inline_edit=False):
    if inline_edit:
        return True
    if not features.get("deals"):
        return False
    if not cfg.get("enabled"):
        return False
    path = (path or "").rstrip("/") or "/"
    if path == "/deals" or path.startswith("/admin"):
        return False
    has_image = cfg.get("use_image") and (cfg.get("image") or "").strip()
    has_text = cfg.get("show_text") and (cfg.get("text") or "").strip()
    has_sub = bool(cfg.get("show_subscribe"))
    if not has_image and not has_text and not has_sub:
        return False
    return True


def set_promo_banner_image(url, store=None):
    """Set banner image URL from inline editor or admin (current location if store set)."""
    cfg = load_promo_banner(store) if store else load_promo_banner_global()
    cleaned = (url or "").strip()
    cfg = dict(cfg)
    cfg["use_image"] = True
    cfg["image"] = cleaned if cleaned else DEFAULT_PROMO_BANNER["image"]
    return save_promo_banner(cfg, store=store)


_INLINE_SCALAR = frozenset({
    "text", "link", "placement", "width", "image_position", "border_style",
    "text_font", "bg_color", "text_color", "subscribe_label",
    "subscribe_border_color", "subscribe_input_color", "subscribe_bar_bg_color",
    "deals_link_color", "deals_btn_text_color", "subscribe_placeholder_color",
    "subscribe_btn_text_color", "subscribe_btn_bg_color",
    "popup_close_bg_color", "popup_close_color",
})
_INLINE_BOOL = frozenset({
    "enabled", "show_text", "use_image", "blink_border", "show_subscribe",
    "subscribe_bar_transparent",
})
_INLINE_INT = frozenset({
    "height", "text_size", "deals_link_size", "subscribe_input_size", "subscribe_btn_size",
    "mobile_text_size", "mobile_deals_link_size",
    "mobile_subscribe_input_size", "mobile_subscribe_btn_size",
    "popup_close_size",
})
_INLINE_FLOAT = frozenset({"overlay"})


def update_promo_banner_field(field, value, store=None):
    """One field from the on-page design panel or inline text edit."""
    field = (field or "").strip()
    if field not in _INLINE_SCALAR | _INLINE_BOOL | _INLINE_INT | _INLINE_FLOAT:
        raise ValueError("unknown field")
    if store:
        cfg = load_promo_banner(store)
    else:
        cfg = load_promo_banner_global()
    cfg = dict(cfg)
    if field == "blink_border":
        cfg["border_style"] = "blink" if (
            bool(value) if isinstance(value, bool) else str(value).lower() in ("1", "true", "yes", "on")
        ) else "none"
    elif field in _INLINE_BOOL:
        cfg[field] = bool(value) if isinstance(value, bool) else str(value).lower() in ("1", "true", "yes", "on")
    elif field in _INLINE_INT:
        cfg[field] = value
    elif field in _INLINE_FLOAT:
        cfg[field] = value
    else:
        cfg[field] = (value or "").strip() if value is not None else ""
    return save_promo_banner(cfg, store=store)
